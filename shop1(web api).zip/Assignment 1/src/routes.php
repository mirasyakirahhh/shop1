<?php

//products route
require __DIR__ . '/Controllers/product.php';
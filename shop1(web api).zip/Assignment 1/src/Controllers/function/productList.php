<?php
//get all products
function getAllProducts($db)
{
$sql = 'Select p.id, p.name, p.description, p.price, p.quantity from products p';
$stmt = $db->prepare ($sql);
$stmt ->execute();
return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

//get product by id
function getProduct($db, $productId)
{
$sql = 'Select p.id, p.name, p.description, p.price, p.quantity from products p ';
$sql .= 'Where p.id = :id';
$stmt = $db->prepare ($sql);
$id = (int) $productId;
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt ->execute();
return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

//post/add new product
function createProduct($db, $form_data) {
    $sql = 'Insert into products (name, description, price, quantity ) ';
    $sql .= 'values (:name, :description, :price, :quantity )';
    $stmt = $db->prepare ($sql); 
    $stmt->bindParam(':name', $form_data['name']);
    $stmt->bindParam(':description', $form_data['description']);
    $stmt->bindParam(':price', ($form_data['price']));
    $stmt->bindParam(':quantity',($form_data['quantity']));
    $stmt->execute();
    return $db->lastInsertID();//insert last number.. continue
}

//delete product by id
function deleteProduct($db,$productId) {
    $sql = ' Delete from products where id = :id';
    $stmt = $db->prepare($sql);
    $id = (int)$productId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    }

    //update put product by id
    function updateProduct($db,$form_data,$productId,) {
    $sql = 'UPDATE products SET name =:name, description =:description, price =:price, quantity =:quantity';
    $sql .=' WHERE id = :id';
    $stmt = $db->prepare ($sql);
    $id = (int)$productId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':name', $form_data['name']);
    $stmt->bindParam(':description', $form_data['description']);
    $stmt->bindParam(':price', $form_data['price']);
    $stmt->bindParam(':quantity',$form_data['quantity']);
    $stmt->execute();
    }